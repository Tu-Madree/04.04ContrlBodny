import './style.css'
import axios, {formToJSON} from 'axios'

axios.get('http://127.0.0.1:8000/api/posts/all').then(res=>{
const tableBody = document.getElementById('tableK')!.querySelector('tbody');
for (let i=0; i<res.data.length; i++){
  let post=res.data[i];
  const row=tableBody.insertRow();
  row.insertCell(0).textContent=post.id;
  row.insertCell(1).textContent=post.title;
  row.insertCell(2).textContent=post.content;
  row.insertCell(3).textContent=post.likes;

}
}).catch(err=>{console.log(err);
})

axios.post('http://127.0.0.1:8000/api/posts/new'{
  
}).then(res=>{
const tableBody = document.getElementById('tableK')!.querySelector('tbody');
for (let i=0; i<res.data.length; i++){
  let post=res.data[i];
  const row=tableBody.insertRow();
  row.insertCell(0).textContent=post.id;
  row.insertCell(1).textContent=post.title;
  row.insertCell(2).textContent=post.content;
  row.insertCell(3).textContent=post.likes;

}
}).catch(err=>{console.log(err);
})



